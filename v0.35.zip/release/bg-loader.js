try{importScripts("background.bundle.js")}catch(r){console.error(r)}
